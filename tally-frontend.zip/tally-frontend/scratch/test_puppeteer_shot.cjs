const puppeteer = require('puppeteer');
const fs = require('fs');

const chromePath = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
].find(p => fs.existsSync(p));

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: chromePath,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });

  await page.setRequestInterception(true);
  page.on('request', req => {
    const url = req.url();
    if (url.includes('/users/me') || url.includes('/auth/me')) {
      req.respond({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          id: 1,
          name: 'Admin Test',
          email: 'admin@tallyconnect.com',
          role: 'ADMIN',
          loginType: 'ADMIN'
        })
      });
    } else if (url.includes('/company/active') || url.includes('/company/list') || url.includes('/company')) {
      req.respond({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify([{ guid: '123', name: 'GL Apr 25-26', financial_year_from: '2025-04-01' }])
      });
    } else {
      req.continue();
    }
  });

  await page.evaluateOnNewDocument(() => {
    localStorage.setItem('tc_token', 'mock_token_123');
    localStorage.setItem('tc_token_origin', '');
    localStorage.setItem('tc_user', JSON.stringify({
      id: 1,
      name: 'Admin Test',
      email: 'admin@tallyconnect.com',
      role: 'ADMIN',
      loginType: 'ADMIN'
    }));
    localStorage.setItem('tc_company_logo', 'https://dummyimage.com/120x40/f97316/ffffff&text=CORP');
    localStorage.setItem('tc_active_company', '123');
  });

  await page.goto('http://localhost:5173', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: 'scratch/verified_dashboard.png' });
  console.log('Saved dashboard screenshot');

  // Go to Ledgers
  await page.evaluate(() => {
    const el = Array.from(document.querySelectorAll('*')).find(e => e.textContent.trim() === 'Ledgers' && e.classList.contains('quick-tile-title'));
    if (el) el.click();
  });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: 'scratch/verified_ledgers.png' });
  console.log('Saved ledgers screenshot');

  await browser.close();
})();
