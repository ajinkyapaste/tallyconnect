const puppeteer = require('puppeteer');
const fs = require('fs');

const chromePath = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
].find(p => fs.existsSync(p));

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: chromePath,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });

  await page.setRequestInterception(true);
  page.on('request', interceptedRequest => {
    const url = interceptedRequest.url();
    if (url.includes('/users/me') || url.includes('/auth/me')) {
      interceptedRequest.respond({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          id: 1,
          name: 'Admin Test',
          email: 'admin@tallyconnect.com',
          role: 'ADMIN',
          loginType: 'ADMIN'
        })
      });
    } else {
      interceptedRequest.continue();
    }
  });

  await page.goto('http://localhost:5173', { waitUntil: 'domcontentloaded' });
  await page.evaluate(() => {
    localStorage.setItem('tc_token', 'mock_token_123');
    localStorage.setItem('tc_token_origin', '');
    localStorage.setItem('tc_user', JSON.stringify({
      id: 1,
      name: 'Admin Test',
      email: 'admin@tallyconnect.com',
      role: 'ADMIN',
      loginType: 'ADMIN'
    }));
    localStorage.setItem('tc_company_logo', 'https://via.placeholder.com/120x40/f97316/ffffff?text=ACME+CORP');
    localStorage.setItem('tc_active_company', 'test_company_guid');
  });

  await page.reload({ waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: 'scratch/verified_dashboard.png' });
  console.log('Saved dashboard screenshot');

  // Go to Ledgers
  await page.evaluate(() => {
    const el = Array.from(document.querySelectorAll('*')).find(e => e.textContent.trim() === 'Ledgers' && e.classList.contains('quick-tile-title'));
    if (el) el.click();
  });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: 'scratch/verified_ledgers.png' });
  console.log('Saved ledgers screenshot');

  // Go to Settings
  await page.evaluate(() => {
    const homeBtn = document.querySelector('button[title*="Dashboard"], .sidebar-item, [data-tab="dashboard"]');
    // or just trigger currentTab state or click Settings tile
    const el = Array.from(document.querySelectorAll('*')).find(e => e.textContent.trim() === 'Settings' && e.classList.contains('quick-tile-title'));
    if (el) el.click();
  });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: 'scratch/verified_settings.png' });
  console.log('Saved settings screenshot');

  await browser.close();
})();
