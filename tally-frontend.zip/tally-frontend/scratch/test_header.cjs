const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });
  await page.goto('http://localhost:5173', { waitUntil: 'networkidle2' });
  await page.evaluate(() => {
    localStorage.setItem('tc_token', 'test_token');
    localStorage.setItem('tc_user', JSON.stringify({ id: 1, name: 'Admin', role: 'admin', email: 'admin@tallyconnect.com' }));
  });
  await page.reload({ waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1000));
  const header = await page.$('.header-actions');
  if (header) {
    await header.screenshot({ path: 'scratch/header_actions.png' });
    console.log('Screenshot saved to scratch/header_actions.png');
  }
  await browser.close();
})();
