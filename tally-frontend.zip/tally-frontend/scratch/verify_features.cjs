const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const chromePath = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
].find(p => fs.existsSync(p));

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: chromePath,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900 });

  await page.setRequestInterception(true);
  page.on('request', req => {
    const url = req.url();
    if (url.includes('/users/me')) {
      req.respond({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          id: 2,
          username: 'workk72002',
          email: 'workk72002@gmail.com',
          role: 'ADMIN',
          avatar_url: ''
        })
      });
    } else if (url.includes('/users') && req.method() === 'GET') {
      req.respond({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify([
          { id: 1, username: 'sudhirtally23', email: 'sudhirtally23@gmail.com', role: 'USER' },
          { id: 2, username: 'workk72002', email: 'workk72002@gmail.com', role: 'ADMIN' },
          { id: 3, username: 'neha.pal072002', email: 'neha.pal072002@gmail.com', role: 'USER' },
          { id: 4, username: 'ajinkyapaste18', email: 'ajinkyapaste18@gmail.com', role: 'USER' }
        ])
      });
    } else if (url.includes('/agent-status') || url.includes('/activity') || url.includes('/notifications')) {
      req.respond({ status: 200, contentType: 'application/json', body: JSON.stringify([]) });
    } else {
      req.continue();
    }
  });

  await page.goto('http://localhost:5173', { waitUntil: 'domcontentloaded' });

  // Mock login session
  await page.evaluate(() => {
    localStorage.setItem('tc_token', 'mock_token_123');
    localStorage.setItem('tc_token_origin', '');
    localStorage.setItem('tc_user', JSON.stringify({
      id: 2,
      username: 'workk72002',
      email: 'workk72002@gmail.com',
      role: 'ADMIN',
      avatar_url: ''
    }));
    localStorage.setItem('tc_active_company', 'comp_guid_1');
    localStorage.setItem('tc_users_view_mode', 'table');
  });

  await page.reload({ waitUntil: 'domcontentloaded' });
  await new Promise(r => setTimeout(r, 1000));

  console.log('Navigating to Users tab...');
  await page.evaluate(() => {
    window.dispatchEvent(new CustomEvent('tc-navigate-tab', { detail: { tab: 'users' } }));
  });
  await new Promise(r => setTimeout(r, 1200));

  const tableInfo = await page.evaluate(() => {
    const table = document.querySelector('table.data-table');
    if (!table) return { hasTable: false };

    const thCheckbox = table.querySelector('thead th input[type="checkbox"]');
    const rowCheckboxes = table.querySelectorAll('tbody tr input[type="checkbox"]');
    const pinButtons = table.querySelectorAll('tbody td button[title="Pin to top"], tbody td button[title="Unpin"]');
    const hideButtons = table.querySelectorAll('tbody td button[title="Hide user from view"]');

    return {
      hasTable: true,
      hasThCheckbox: !!thCheckbox,
      rowCheckboxesCount: rowCheckboxes.length,
      pinButtonsCount: pinButtons.length,
      hideButtonsCount: hideButtons.length
    };
  });

  console.log('Users Table verification:', tableInfo);

  const screenshotDir = path.resolve(__dirname);
  await page.screenshot({ path: path.join(screenshotDir, 'users_table_verified.png') });
  console.log('Saved users_table_verified.png');

  // Select first user and check if bulk selection bar appears
  console.log('Selecting first user...');
  await page.evaluate(() => {
    const firstCheckbox = document.querySelector('tbody tr input[type="checkbox"]');
    if (firstCheckbox) firstCheckbox.click();
  });
  await new Promise(r => setTimeout(r, 600));

  const selectionState = await page.evaluate(() => {
    const bulkBar = document.querySelector('span.badge');
    const isSelectedRow = document.querySelector('tbody tr[style*="rgba(0, 122, 255, 0.08)"]');
    return {
      hasBulkBar: !!bulkBar,
      bulkText: bulkBar ? bulkBar.textContent : null,
      hasHighlightedRow: !!isSelectedRow
    };
  });
  console.log('Selection state:', selectionState);

  await page.screenshot({ path: path.join(screenshotDir, 'users_selected_verified.png') });
  console.log('Saved users_selected_verified.png');

  // Switch to cards view and check
  console.log('Switching to Cards view...');
  await page.evaluate(() => {
    const cardsBtn = Array.from(document.querySelectorAll('.display-prefs-btn, button')).find(b => b.title && b.title.includes('Cards'));
    if (cardsBtn) cardsBtn.click();
  });
  await new Promise(r => setTimeout(r, 600));

  const cardsInfo = await page.evaluate(() => {
    const cardCheckboxes = document.querySelectorAll('.glass-panel input[type="checkbox"]');
    const cardPinButtons = document.querySelectorAll('.glass-panel button[title*="Pin user"]');
    const cardHideButtons = document.querySelectorAll('.glass-panel button[title*="Hide user"]');
    return {
      cardCheckboxesCount: cardCheckboxes.length,
      cardPinButtonsCount: cardPinButtons.length,
      cardHideButtonsCount: cardHideButtons.length
    };
  });
  console.log('Cards View verification:', cardsInfo);
  await page.screenshot({ path: path.join(screenshotDir, 'users_cards_verified.png') });
  console.log('Saved users_cards_verified.png');

  // Open User menu and check "My Profile & Avatar"
  console.log('Opening user menu...');
  await page.evaluate(() => {
    const clockOrAvatar = document.querySelector('.working-clock-pill, .user-avatar, .user-menu');
    if (clockOrAvatar) clockOrAvatar.click();
  });
  await new Promise(r => setTimeout(r, 600));

  const userMenuInfo = await page.evaluate(() => {
    const dropdown = document.querySelector('.user-menu-dropdown');
    if (!dropdown) return { hasDropdown: false };
    const buttons = Array.from(dropdown.querySelectorAll('button')).map(b => b.textContent.trim());
    return {
      hasDropdown: true,
      buttons
    };
  });
  console.log('User Menu verification:', userMenuInfo);
  await page.screenshot({ path: path.join(screenshotDir, 'user_menu_verified.png') });
  console.log('Saved user_menu_verified.png');

  // Click "My Profile & Avatar"
  console.log('Clicking My Profile & Avatar...');
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('.user-menu-dropdown button')).find(b => b.textContent.includes('Profile'));
    if (btn) btn.click();
  });
  await new Promise(r => setTimeout(r, 600));

  const profileModalInfo = await page.evaluate(() => {
    const modalTitle = document.querySelector('h3');
    const uploadBtn = document.querySelector('button.btn-secondary');
    return {
      title: modalTitle ? modalTitle.textContent : null,
      hasUploadBtn: !!uploadBtn
    };
  });
  console.log('Profile Modal verification:', profileModalInfo);
  await page.screenshot({ path: path.join(screenshotDir, 'profile_modal_verified.png') });
  console.log('Saved profile_modal_verified.png');

  // Navigate to Settings to verify Company Logo Size
  console.log('Navigating to Settings...');
  await page.evaluate(() => {
    const closeBtn = document.querySelector('.icon-btn');
    if (closeBtn) closeBtn.click();
    window.dispatchEvent(new CustomEvent('tc-navigate-tab', { detail: { tab: 'settings' } }));
  });
  await new Promise(r => setTimeout(r, 800));

  // Click on "Admin & Visibility" tab in Settings
  await page.evaluate(() => {
    const adminTab = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Admin & Visibility'));
    if (adminTab) adminTab.click();
  });
  await new Promise(r => setTimeout(r, 600));

  const settingsLogoInfo = await page.evaluate(() => {
    const logoHeading = Array.from(document.querySelectorAll('h4')).find(h => h.textContent.includes('Company Logo'));
    const sizeLabel = Array.from(document.querySelectorAll('label')).find(l => l.textContent.includes('Logo Display Size'));
    const defaultBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Default (36px)'));
    const allButtons = Array.from(document.querySelectorAll('button')).map(b => b.textContent.trim());
    return {
      hasLogoHeading: !!logoHeading,
      hasSizeLabel: !!sizeLabel,
      sizeText: sizeLabel ? sizeLabel.textContent : null,
      hasDefaultBtn: !!defaultBtn,
      buttonsSnippet: allButtons.filter(b => b.includes('px'))
    };
  });
  console.log('Settings Company Logo Size verification:', settingsLogoInfo);
  await page.screenshot({ path: path.join(screenshotDir, 'settings_logo_size_verified.png') });
  console.log('Saved settings_logo_size_verified.png');

  await browser.close();
  console.log('All verifications finished successfully.');
})();
