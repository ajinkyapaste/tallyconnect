const puppeteer = require('puppeteer');
const fs = require('fs');

const chromePath = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
].find(p => fs.existsSync(p));

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: chromePath,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });

  const averlonLogoSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="75" viewBox="0 0 300 75">
    <text x="10" y="45" font-family="Arial, sans-serif" font-size="42" font-weight="900" fill="#003366">AVERLON</text>
    <text x="14" y="66" font-family="Arial, sans-serif" font-size="12" font-weight="600" fill="#0066cc">Strength • Reliability • Stability</text>
  </svg>`;
  const averlonDataUrl = 'data:image/svg+xml;utf8,' + encodeURIComponent(averlonLogoSvg);

  await page.setRequestInterception(true);
  page.on('request', req => {
    const url = req.url();
    if (url.includes('/auth/login') || url.includes('/login')) {
      req.respond({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          token: 'mock_jwt_token',
          user: {
            id: 1,
            username: 'Admin',
            name: 'Admin',
            email: 'admin@tallyconnect.com',
            role: 'ADMIN',
            loginType: 'ADMIN'
          }
        })
      });
    } else if (url.includes('/users/me') || url.includes('/auth/me')) {
      req.respond({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          id: 1,
          username: 'Admin',
          name: 'Admin',
          email: 'admin@tallyconnect.com',
          role: 'ADMIN',
          loginType: 'ADMIN'
        })
      });
    } else if (url.includes('/company/active') || url.includes('/company/list') || url.includes('/company')) {
      req.respond({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify([{ guid: '123', name: 'Gl Apr 25-26', financial_year_from: '2025-04-01' }])
      });
    } else {
      req.continue();
    }
  });

  await page.goto('http://localhost:5173', { waitUntil: 'networkidle2' });
  await page.evaluate((logo) => {
    localStorage.setItem('tc_company_logo', logo);
    localStorage.setItem('tc_active_company', '123');
  }, averlonDataUrl);

  // Fill in form and click sign in
  await page.type('#tc-username', 'admin@tallyconnect.com');
  await page.type('input[type="password"]', 'password123');
  await page.click('button[type="submit"]');

  // Wait for post-login cinematic loader or dashboard
  await new Promise(r => setTimeout(r, 3500));

  await page.screenshot({ path: 'scratch/verified_full_header.png' });
  console.log('Saved full header screenshot after login');

  const headerActions = await page.$('.header-actions');
  if (headerActions) {
    await headerActions.screenshot({ path: 'scratch/verified_header_actions_large.png' });
    console.log('Saved header actions screenshot');
  }

  await browser.close();
})();
