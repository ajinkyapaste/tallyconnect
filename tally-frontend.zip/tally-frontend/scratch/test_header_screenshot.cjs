const puppeteer = require('puppeteer');
const fs = require('fs');

const chromePath = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
].find(p => fs.existsSync(p));

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: chromePath,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });
  await page.goto('http://localhost:5173', { waitUntil: 'networkidle2' });
  await page.evaluate(() => {
    localStorage.setItem('tc_token', 'test_token');
    localStorage.setItem('tc_user', JSON.stringify({ id: 1, name: 'Admin', role: 'admin', email: 'admin@tallyconnect.com' }));
  });
  await page.reload({ waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1200));
  const header = await page.$('.header-actions');
  if (header) {
    await header.screenshot({ path: 'scratch/header_actions_current.png' });
    console.log('Saved current header screenshot to scratch/header_actions_current.png');
  }
  await browser.close();
})();
